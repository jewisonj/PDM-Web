# Creo Workspace Comparison Tool

A web-based interface for comparing files in a Creo workspace against a PDM vault, built using CreoJS and PowerShell.

## Overview

This tool provides real-time comparison between CAD files in your active Creo workspace and their versions in a PDM vault. It identifies files that need check-in, files that are out of date, and new files not yet in the vault.

**Key Features:**
- Auto-scans workspace when page loads
- Real-time timestamp comparison (workspace vs vault)
- File type filtering (PRT, ASM, DRW)
- Search functionality
- One-click file opening in Creo
- Resizable table columns
- Color-coded status indicators

## Architecture

```
┌─────────────────┐         ┌──────────────────┐         ┌─────────────┐
│  Creo Browser   │────────▶│  PowerShell      │────────▶│  SQLite DB  │
│  (CreoJS HTML)  │  HTTP   │  Web Server      │  Query  │  (Vault)    │
│                 │◀────────│  (Port 8082)     │◀────────│             │
└─────────────────┘  JSON   └──────────────────┘  Result └─────────────┘
        │                            │
        │                            │
        ▼                            ▼
  List workspace files        Read vault files
  Get timestamps              Compare timestamps
  Display results             Return status
```

## Components

### 1. HTML Interface (workspace_compare_v2.html)

**Location:** `C:\Program Files\PTC\Creo 10.0.0.0\Common Files\apps\creojs\creojsweb\`

**CreoJS Functions:**
- `getWorkspaceFiles()` - Lists all PRT/ASM/DRW files in current working directory
- `openFileInCreo(filename)` - Opens/activates a file in Creo

**Key Technologies:**
- **CreoJS** - Creo JavaScript API for file access and manipulation
- **Fetch API** - AJAX calls to PowerShell server
- **Local file timestamps** - Browser-based timestamp reading via fetch HEAD requests

**Features:**
- Auto-scan on page load
- File type icons (🔷 PRT, 📦 ASM, 📐 DRW)
- Checkbox filters for file types
- Real-time search
- Resizable columns
- Debug console for troubleshooting

### 2. PowerShell Web Server (CompareWorkspace_Simple.ps1)

**Location:** `D:\PDM_PowerShell\`

**Endpoints:**
- `POST /api/compare-filelist` - Receives file list, compares against vault, returns status

**Comparison Logic:**
```powershell
# For each workspace file:
1. Query database: SELECT file_path FROM files WHERE file_path LIKE '%filename'
2. If file exists in vault:
   - Get actual file from D:\PDM_Vault\CADData\
   - Read LastWriteTime
   - Compare with workspace timestamp
   - Return status based on difference:
     * Within 2 seconds → "Up To Date"
     * Workspace newer → "Modified Locally"
     * Vault newer → "Out of Date"
3. If file not in vault → "New"
```

**Status Categories:**
- **Up To Date** - Timestamps match (within 2 second tolerance)
- **Modified Locally** - Workspace file is newer (needs check-in)
- **Out of Date** - Vault file is newer (needs update)
- **New** - File doesn't exist in vault

## Database Schema

The tool queries the PDM SQLite database:

```sql
-- files table structure
CREATE TABLE files (
    file_id INTEGER PRIMARY KEY,
    item_number TEXT NOT NULL,
    file_path TEXT NOT NULL,        -- Full path: D:\PDM_Vault\CADData\filename.prt
    file_type TEXT NOT NULL,         -- 'CAD', 'STEP', 'DXF', etc.
    revision TEXT,
    iteration INTEGER,
    added_at TEXT                    -- When checked into vault
);
```

**Query used:**
```sql
SELECT file_path FROM files 
WHERE file_path LIKE '%filename.prt' 
LIMIT 1;
```

## Installation

### 1. Deploy HTML File

```powershell
# Copy HTML to CreoJS web directory
Copy-Item workspace_compare_v2.html `
  -Destination "C:\Program Files\PTC\Creo 10.0.0.0\Common Files\apps\creojs\creojsweb\"
```

### 2. Configure PowerShell Server

**Edit CompareWorkspace_Simple.ps1:**
```powershell
$Global:VaultPath = "D:\PDM_Vault\CADData"
$Global:DBPath = "D:\PDM_Vault\pdm.sqlite"
$Global:Port = 8082
```

### 3. Setup Firewall Rule

```powershell
# Allow inbound connections on port 8082
New-NetFirewallRule -DisplayName "PDM Workspace Compare" `
  -Direction Inbound -LocalPort 8082 -Protocol TCP -Action Allow
```

### 4. Start Server

```powershell
# Run as Administrator (first time only for port binding)
cd D:\PDM_PowerShell
.\CompareWorkspace_Simple.ps1
```

## Usage

### In Creo

1. Set your working directory to the folder you want to scan
2. Open Creo embedded browser
3. Navigate to: `file:///C:/Program%20Files/PTC/Creo%2010.0.0.0/Common%20Files/apps/creojs/creojsweb/workspace_compare_v2.html`
4. Page auto-scans and displays results

### Table Columns

| Column | Description |
|--------|-------------|
| Type | File type icon (PRT/ASM/DRW) |
| Status | Up To Date, Modified Locally, Out of Date, New |
| File | Filename |
| Action | Open button (opens file in Creo) |
| Description | CAD file description (future feature) |
| Last Modified (Local) | Workspace file timestamp |
| Last Modified (Vault) | Vault file timestamp |

### Filters

- **Search box** - Filter by filename
- **File type checkboxes** - Show/hide PRT, ASM, DRW files
- **Column resizing** - Drag column borders to resize

## CreoJS API Reference

### Key APIs Used

**Session and File Listing:**
```javascript
// Get current Creo session
var session = pfcGetCurrentSession();

// Get working directory
var workingDir = session.GetCurrentDirectory();

// List files by pattern
var parts = session.ListFiles("*.prt", pfcFileListOpt.FILE_LIST_LATEST, workingDir);
```

**Opening Files:**
```javascript
// Create model descriptor
var descr = pfcModelDescriptor.Create(pfcModelType.MDL_PART, filename, "");

// Retrieve/open model
var model = session.RetrieveModel(descr);

// Display (brings to front)
model.Display();

// Set as current
session.CurrentModel = model;
```

### Important Limitations

1. **No localStorage/sessionStorage** - Browser storage APIs not supported in Creo browser
2. **File timestamps** - Cannot read local file metadata directly from JavaScript
3. **CORS requirements** - Server must send proper CORS headers for file:// origin
4. **Description parameters** - `pfcRetrieveProEModelDescrip()` may not be available in all Creo versions

## Troubleshooting

### Common Issues

**1. "Failed to fetch" error**
- **Cause:** Server not running or firewall blocking
- **Fix:** 
  ```powershell
  # Check if server is running
  netstat -ano | findstr :8082
  
  # Add firewall rule
  New-NetFirewallRule -DisplayName "PDM Compare" -LocalPort 8082 -Protocol TCP -Action Allow
  ```

**2. Files showing as "In Vault" when they're not**
- **Cause:** Wrong database column name (was using `filename` instead of `file_path`)
- **Fix:** Query uses `file_path LIKE '%filename'` pattern matching

**3. Open button doesn't bring window to front**
- **Cause:** `Activate()` alone may not be enough
- **Fix:** Use `model.Display()` first, then set `CurrentModel`

**4. All timestamps show "Unknown"**
- **Cause:** Browser can't access local file system
- **Fix:** Timestamps are sent from CreoJS in the file list payload

**5. Server error: "You cannot call a method on a null-valued expression"**
- **Cause:** SQLite returns null for non-existent files
- **Fix:** Check for null before calling `.Trim()` or `.GetType()`

### Debug Console

The HTML includes a built-in debug console at the bottom:

- Shows file scan progress
- Displays server communication
- Logs CreoJS function calls
- Test button to verify CreoJS availability

**Using Debug Console:**
```javascript
// Test if CreoJS is available
Click "Test CreoJS" button

// Check console output for:
- typeof CreoJS = object  (should be 'object')
- typeof CreoJS.openFileInCreo = function  (should be 'function')
```

## Future Enhancements

### Description Parameter Reading

Currently descriptions are empty. Potential solutions:

**Option 1: Read from item database**
```sql
-- Join with items table to get description
SELECT f.file_path, i.description 
FROM files f
JOIN items i ON f.item_number = i.item_number
WHERE f.file_path LIKE '%filename.prt';
```

**Option 2: Batch file opening**
- Open files in background
- Read DESCRIPTION parameter
- Close files
- Cache results

**Option 3: XML parsing**
- Parse Creo .prt.# XML files directly
- Extract designated parameters without opening

### Additional Features

- **Batch check-in** - Select multiple files and check in
- **Conflict resolution** - Handle files modified in both locations
- **Revision history** - Show file change history
- **BOM awareness** - Highlight assemblies with modified children
- **Real-time sync** - Auto-refresh when files change

## Performance Considerations

**Current Performance:**
- ~100 files: 2-3 seconds
- ~500 files: 10-15 seconds
- ~1000 files: 30+ seconds

**Bottlenecks:**
1. Individual SQLite queries per file (N+1 query problem)
2. File system access for each vault file timestamp
3. Network round-trip for server comparison

**Optimization Strategies:**

**1. Batch database query:**
```sql
-- Single query for all files
SELECT file_path, added_at 
FROM files 
WHERE file_path IN ('file1.prt', 'file2.prt', ...);
```

**2. Cache vault file info:**
```powershell
# Build hash table once
$vaultFiles = @{}
Get-ChildItem "D:\PDM_Vault\CADData\*.prt" | ForEach-Object {
    $vaultFiles[$_.Name] = $_.LastWriteTime
}
```

**3. Parallel processing:**
```powershell
# Use PowerShell jobs for concurrent queries
$files | ForEach-Object -Parallel {
    # Check vault status
} -ThrottleLimit 10
```

## Code Examples

### Complete Workflow Example

```javascript
// 1. Scan workspace (auto-runs on load)
async function scanCreoWorkspace() {
    // Get files from Creo
    const result = await CreoJS.getWorkspaceFiles();
    
    // Get timestamps (browser-based, may fail)
    for (let file of result.files) {
        try {
            const response = await fetch('file:///' + file.fullPath.replace(/\\/g, '/'), 
                                        {method: 'HEAD'});
            file.lastWriteTime = new Date(
                response.headers.get('Last-Modified')
            ).toLocaleString();
        } catch (e) {
            file.lastWriteTime = 'Unknown';
        }
    }
    
    // Send to server for comparison
    const response = await fetch('http://DATASERVER:8082/api/compare-filelist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            workspacePath: result.workingDir,
            files: result.files 
        })
    });
    
    const data = await response.json();
    displayResults(data, result.files);
}
```

### PowerShell Server Handler Example

```powershell
# Compare file timestamps
$query = "SELECT file_path FROM files WHERE file_path LIKE '%$safeFileName' LIMIT 1;"
$dbResult = Query-SQLite -Query $query

if ($dbResult -is [string] -and $dbResult.Trim().Length -gt 0) {
    $vaultPath = $dbResult.Trim()
    
    if (Test-Path $vaultPath) {
        $fileInfo = Get-Item -Path $vaultPath
        $vaultTimestamp = $fileInfo.LastWriteTime
        
        # Parse workspace time
        $wsTime = [DateTime]::Parse($workspaceTime)
        $timeDiff = ($wsTime - $vaultTimestamp).TotalSeconds
        
        # Determine status
        if ([Math]::Abs($timeDiff) -lt 2) {
            $status = "Up To Date"
        } elseif ($timeDiff -gt 2) {
            $status = "Modified Locally"
        } else {
            $status = "Out of Date"
        }
    }
}
```

## Security Considerations

1. **No authentication** - Server accepts requests from any origin
2. **SQL injection** - Filename escaping prevents basic attacks
3. **File path traversal** - LIKE pattern could match wrong files
4. **CORS wide open** - `Access-Control-Allow-Origin: *`

**For production use:**
- Add authentication/authorization
- Use parameterized queries
- Validate file paths strictly
- Restrict CORS to specific origins
- Use HTTPS for server communication

## Related Documentation

- [PDM System Skill](../pdm-system/SKILL.md) - Core PDM architecture
- [CreoJS Documentation](https://support.ptc.com/help/creo/creo_pma/r10.0/usascii/index.html#page/part_modeling/part_modeling/creojs/creojs_intro.html)
- [PowerShell Web Server](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/invoke-webrequest)
