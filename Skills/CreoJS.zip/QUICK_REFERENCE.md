# Quick Reference - Creo Workspace Compare

## File Locations

```
# HTML Interface
C:\Program Files\PTC\Creo 10.0.0.0\Common Files\apps\creojs\creojsweb\workspace_compare.html

# PowerShell Server
D:\PDM_PowerShell\CompareWorkspace.ps1

# Database
D:\PDM_Vault\pdm.sqlite

# Vault Files
D:\PDM_Vault\CADData\
```

## Quick Start

```powershell
# 1. Start server (as Administrator first time)
cd D:\PDM_PowerShell
.\CompareWorkspace.ps1

# 2. In Creo browser, navigate to:
file:///C:/Program%20Files/PTC/Creo%2010.0.0.0/Common%20Files/apps/creojs/creojsweb/workspace_compare.html
```

## Status Colors

| Status | Color | Meaning |
|--------|-------|---------|
| Up To Date | Green | Workspace and vault match |
| Modified Locally | Yellow | Workspace is newer - needs check-in |
| Out of Date | Cyan | Vault is newer - needs update |
| New | Red | File not in vault yet |

## File Type Icons

- 🔷 **PRT** - Parts (blue)
- 📦 **ASM** - Assemblies (orange)
- 📐 **DRW** - Drawings (green)

## Common Commands

### Server Management
```powershell
# Check if server is running
netstat -ano | findstr :8082

# Kill server by port
$port = Get-NetTCPConnection -LocalPort 8082
Stop-Process -Id $port.OwningProcess -Force

# Add firewall rule
New-NetFirewallRule -DisplayName "PDM Compare" -LocalPort 8082 -Protocol TCP -Action Allow
```

### Database Queries
```powershell
# Check if file exists in vault
sqlite3.exe D:\PDM_Vault\pdm.sqlite "SELECT file_path FROM files WHERE file_path LIKE '%filename.prt';"

# Get file modification date
$file = Get-Item "D:\PDM_Vault\CADData\filename.prt"
$file.LastWriteTime
```

## Troubleshooting

| Problem | Solution |
|---------|----------|
| "Failed to fetch" | Start server, check firewall |
| "temp_test shows In Vault" | Was actually in vault - create new test file |
| Open doesn't work | Use model.Display() - already implemented |
| Timestamps "Unknown" | Workspace timestamps come from CreoJS payload |

## API Endpoints

### POST /api/compare-filelist

**Request:**
```json
{
  "workspacePath": "J:\\Aethon\\Project\\Folder",
  "files": [
    {
      "filename": "part.prt",
      "fullPath": "J:\\Aethon\\Project\\Folder\\part.prt",
      "lastWriteTime": "12/27/2025, 1:00:00 AM",
      "description": ""
    }
  ]
}
```

**Response:**
```json
{
  "upToDate": [
    {
      "file": "part1.prt",
      "workspaceTime": "12/27/2025, 1:00:00 AM",
      "vaultTime": "12/27/2025, 1:00:00 AM",
      "status": "Up To Date"
    }
  ],
  "needCheckIn": [...],
  "needUpdate": [...],
  "notInVault": [...]
}
```

## CreoJS Snippets

### List All Files
```javascript
var session = pfcGetCurrentSession();
var dir = session.GetCurrentDirectory();
var parts = session.ListFiles("*.prt", pfcFileListOpt.FILE_LIST_LATEST, dir);
```

### Open File
```javascript
var descr = pfcModelDescriptor.Create(pfcModelType.MDL_PART, "filename.prt", "");
var model = session.RetrieveModel(descr);
model.Display();
session.CurrentModel = model;
```

### Get Working Directory
```javascript
var session = pfcGetCurrentSession();
var workingDir = session.GetCurrentDirectory();
// Returns: "J:\\Aethon\\Project\\Folder"
```
