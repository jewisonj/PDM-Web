# Creo Workspace Compare - Installation Guide

## Prerequisites

- PTC Creo Parametric 10.0 with CreoJS enabled
- PowerShell 5.1 or higher
- SQLite3 command-line tool
- PDM vault with SQLite database

## Installation Steps

### 1. Copy Files

```powershell
# Copy HTML to Creo web directory
Copy-Item code\workspace_compare.html `
  -Destination "C:\Program Files\PTC\Creo 10.0.0.0\Common Files\apps\creojs\creojsweb\"

# Copy PowerShell server
Copy-Item code\CompareWorkspace.ps1 -Destination "D:\PDM_PowerShell\"
```

### 2. Configure Server

Edit `D:\PDM_PowerShell\CompareWorkspace.ps1`:

```powershell
# Update these paths to match your setup
$Global:VaultPath = "D:\PDM_Vault\CADData"
$Global:DBPath = "D:\PDM_Vault\pdm.sqlite"
$Global:Port = 8082
```

### 3. Setup Firewall (First Time Only)

Run PowerShell **as Administrator**:

```powershell
# Allow inbound connections
New-NetFirewallRule `
  -DisplayName "PDM Workspace Compare" `
  -Direction Inbound `
  -LocalPort 8082 `
  -Protocol TCP `
  -Action Allow

# Optional: Allow URL reservation for non-admin use
netsh http add urlacl url=http://+:8082/ user=EVERYONE
```

### 4. Start Server

```powershell
# Navigate to PowerShell directory
cd D:\PDM_PowerShell

# Run server (as Administrator first time, then normal user is fine)
.\CompareWorkspace.ps1
```

You should see:
```
==================================================
  Workspace Comparison Server (Simple)
==================================================

Server running on: http://DATASERVER:8082
Database: D:\PDM_Vault\pdm.sqlite

Press Ctrl+C to stop...
==================================================
```

### 5. Access in Creo

1. Open Creo Parametric
2. Set your working directory to a project folder
3. Open embedded browser (Tools → Web Browser)
4. Navigate to:
   ```
   file:///C:/Program%20Files/PTC/Creo%2010.0.0.0/Common%20Files/apps/creojs/creojsweb/workspace_compare.html
   ```

The page will auto-scan and show results!

## Verification

### Test Server

```powershell
# From any PowerShell window
Invoke-WebRequest -Uri "http://localhost:8082/api/compare-filelist" -Method OPTIONS
```

Should return: `StatusCode: 200`

### Test CreoJS

In the web interface:
1. Click "Test CreoJS" button in debug console
2. Should show:
   ```
   typeof CreoJS = object
   typeof CreoJS.openFileInCreo = function
   ```

## Troubleshooting

### Server won't start

**Error:** "Access is denied"
```powershell
# Solution: Run as Administrator OR add URL reservation
netsh http add urlacl url=http://+:8082/ user=EVERYONE
```

**Error:** "Address already in use"
```powershell
# Find what's using port 8082
netstat -ano | findstr :8082

# Kill the process
taskkill /PID <PID> /F
```

### Page shows "Failed to fetch"

1. Check server is running: `netstat -ano | findstr :8082`
2. Check firewall rule exists: `Get-NetFirewallRule -DisplayName "PDM*"`
3. Try accessing from server machine first
4. Check CORS headers in server response

### Files not comparing correctly

1. Check database path is correct
2. Verify SQLite3.exe is in PATH: `sqlite3.exe --version`
3. Test database query:
   ```powershell
   sqlite3.exe D:\PDM_Vault\pdm.sqlite "SELECT COUNT(*) FROM files;"
   ```

## Optional: Run as Windows Service

To keep the server running automatically:

```powershell
# 1. Install NSSM (Non-Sucking Service Manager)
choco install nssm

# 2. Create service
nssm install PDMWorkspaceCompare `
  "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" `
  "-ExecutionPolicy Bypass -File D:\PDM_PowerShell\CompareWorkspace.ps1"

# 3. Start service
nssm start PDMWorkspaceCompare
```

## Uninstallation

```powershell
# Remove HTML
Remove-Item "C:\Program Files\PTC\Creo 10.0.0.0\Common Files\apps\creojs\creojsweb\workspace_compare.html"

# Remove PowerShell script
Remove-Item "D:\PDM_PowerShell\CompareWorkspace.ps1"

# Remove firewall rule
Remove-NetFirewallRule -DisplayName "PDM Workspace Compare"

# Remove URL reservation (if added)
netsh http delete urlacl url=http://+:8082/
```

## Next Steps

See [SKILL.md](SKILL.md) for complete documentation including:
- Architecture details
- CreoJS API reference
- Performance optimization
- Future enhancements
