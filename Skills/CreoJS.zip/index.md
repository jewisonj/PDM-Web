# Creo Workspace Compare Skill

Real-time workspace-to-vault comparison tool for Creo Parametric with PDM integration.

## Documentation

- **[README.md](README.md)** - Installation and setup guide
- **[SKILL.md](SKILL.md)** - Complete technical documentation
- **[QUICK_REFERENCE.md](QUICK_REFERENCE.md)** - Common commands and snippets

## Code

- **[code/workspace_compare.html](code/workspace_compare.html)** - CreoJS web interface
- **[code/CompareWorkspace.ps1](code/CompareWorkspace.ps1)** - PowerShell web server

## What This Tool Does

Compares CAD files in your Creo workspace against a PDM vault to show:

- ✅ **Up To Date** - Files match between workspace and vault
- ⚠️ **Modified Locally** - Workspace newer, needs check-in
- 📥 **Out of Date** - Vault newer, needs update  
- 🆕 **New** - File not in vault yet

## Key Features

- Auto-scan on page load
- One-click file opening
- File type filtering (PRT/ASM/DRW)
- Real-time search
- Resizable columns
- Debug console

## Quick Start

```powershell
# 1. Start server
cd D:\PDM_PowerShell
.\CompareWorkspace.ps1

# 2. Open in Creo browser
file:///C:/Program%20Files/PTC/Creo%2010.0.0.0/Common%20Files/apps/creojs/creojsweb/workspace_compare.html
```

See [README.md](README.md) for detailed installation instructions.
